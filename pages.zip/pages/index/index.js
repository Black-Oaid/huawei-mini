Page({
    data: {
        // 分类数据（保持不变）
        categories: [
            { id: 1, name: "手机", icon: "/images/category-phone.png" },
            { id: 2, name: "电视", icon: "/images/category-tv.png" },
            { id: 3, name: "笔记本", icon: "/images/category-laptop.png" },
            { id: 4, name: "家电", icon: "/images/category-home.png" },
            { id: 5, name: "智能硬件", icon: "/images/category-smart.png" },
            { id: 6, name: "穿戴", icon: "/images/category-wear.png" },
            { id: 7, name: "健康", icon: "/images/category-health.png" },
            { id: 8, name: "生活", icon: "/images/category-life.png" },
            { id: 9, name: "出行", icon: "/images/category-car.png" },
            { id: 10, name: "配件", icon: "/images/category-parts.png" }
        ],
        // 商品数据（初始为空，通过API获取）
        products: []
    },

    onLoad() {
        console.log('页面加载完成，开始获取商品数据...');
        this.fetchProducts();
    },

    // 从后端API获取商品数据
    fetchProducts() {
        wx.request({
            url: 'http://localhost:8080/api/v1/Indexes', // 后端接口URL
            method: 'GET',
            success: (res) => {
                if (res.statusCode === 200 && res.data.code === 200) {
                    // 转换数据库字段到前端字段
                    const products = res.data.data.map(item => ({
                        id: item.id,
                        title: item.name,      // 数据库中的name对应前端的title
                        desc: item.desc,       // 数据库中的desc直接使用
                        price: item.price,     // 数据库中的price直接使用
                        image: item.avatar     // 数据库中的avatar对应前端的image
                    }));
                    this.setData({ products });
                    console.log('商品数据获取成功:', products);
                } else {
                    console.error('获取商品数据失败:', res);
                    wx.showToast({
                        title: '加载商品失败',
                        icon: 'none'
                    });
                }
            },
            fail: (err) => {
                console.error('请求失败:', err);
                wx.showToast({
                    title: '网络请求失败',
                    icon: 'none'
                });
            }
        });
    },

    // 点击搜索按钮跳转搜索页（保持不变）
    goToSearch() {
        wx.navigateTo({
            url: '/pages/list/list'
        });
    },

    // // 处理商品点击事件（保持不变）
    // handleProductClick(e) {
    //     const productId = e.currentTarget.dataset.id;
    //     console.log('点击商品:', productId);
    //     wx.navigateTo({
    //         url: `/pages/product/detail?id=${productId}`
    //     });
    // }
});