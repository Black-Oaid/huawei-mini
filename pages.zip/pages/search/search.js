// pages/search/search.js
Page({
  data: {
    name: "",
    guessTags: [       // 猜你想搜标签
      "附近的小米之家", "空调", "充电宝", "风扇",
      "Redmi K80", "显示器", "路由器", "空气净化器"
    ],
    hotList: [         // 小米热搜数据（模拟，实际可接口请求）
      { img: "/images/xiaomi_icons/pms_1664192126.84785883.png", text: "Xiaomi 15 系列" },
      { img: "/images/xiaomi_icons/pms_1692003921.02326149.png", text: "REDMI Turbo 4 Pro" },
      { img: "/images/xiaomi_icons/pms_1710919699.63515243.png", text: "Xiaomi Watch S4 41mm" },
      { img: "/images/xiaomi_icons/pms_1721369925.99078028.png", text: "REDMI K80系列" },
      { img: "/images/xiaomi_icons/pms_1721369926.02045239.png", text: "Redmi 14C" },
      { img: "/images/xiaomi_icons/pms_1710919699.63515243.png", text: "Redmi Note 14系列" },
    ]
  },
  searchChangeHandler:function(e){
    this.setData({name: e.detail });
  },
  goListPage:function() {
    wx.navigateTo({url: '/pages/list/list?name=' + this.data.name})
  },

  onTagTap(e) {
    // 点击“猜你想搜”标签逻辑
    wx.showToast({ title: `点击标签：${e.currentTarget.dataset.text}`, icon: "none" });
  },

  onHotItemTap(e) {
    // 点击“小米热搜” item 逻辑
    wx.showToast({ title: `点击热搜：${e.currentTarget.dataset.text}`, icon: "none" });
  }
})