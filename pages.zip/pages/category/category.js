import {request} from '../../utils/request.js';
Page({
    data:{
        activeId:0,
        categoryList: [],
        series:[]
    },
    onReady: async function(){
        const categoryList = await request({url:"/categories"}); 
        this.setData({categoryList:categoryList});
        this.toggleId(categoryList[0].id);
    },
    tapHandler: function(e){
        this.toggleId(e.currentTarget.dataset.id)
    },
    toggleId: async function(newId){
        if(newId === this.data.activeId) {return;}
        this.setData({activeId:newId});
        const productList = await request({url:"/products?categoryId=" + newId});
        // 回来的商品列表数据data不方便进行页面渲染，所以要对数据进行变形，变形后再赋值给prosuctList
        const series = productList.reduce((result, product) => {
            let seriesName = product.series;
            let i = result.findIndex(item => item.seriesName === seriesName);
            if(i === -1) {
                result.push({seriesName: seriesName, list: [{...product}]})
            } else {
                result[i].list.push({...product})
            }
            return result;
        }, []);
        this.setData({series:series});
    },
    goSearchPage:function(){
        console.log(123) 
        wx.navigateTo({
          url: '/pages/search/search',
        })
    }
})