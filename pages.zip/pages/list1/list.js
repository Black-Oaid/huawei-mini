import {request} from '../../utils/request'
Page({
  data: {
      name:"",       //保存用户搜索时输入的关键字
      list:[],       //当前页面要显示的商品数据
      page:1,        //当前页码
      limit:6,        //页容量
      hasMore:true,   //标识是否还有更多商品可供加载
      loading:false   //标识当前是否正在加载商品数据
  },
  onLoad(options) {
      this.setData({name:options.name});
  },
  onReady() {
      this.updateList(1);
  },
  onReachBottom() {
      this.updateList(this.data.page + 1);
  },
  async updateList(newPage){
    if(this.data.loading) {return;}
    if(this.data.hasMore === false) {return;}
    const url=`/products?name=${this.data.name}&page=${newPage}&limit=${this.data.limit}`;
    this.setData({loading:true});
    const list = await request({url:url});
    await new Promise(resolve => setTimeout(resolve,2000));
    this.setData({
         list:[...this.data.list,...list],
         page:newPage,
         hasMore: list.length === this.data.limit,
         loading:false
        });
  }
})